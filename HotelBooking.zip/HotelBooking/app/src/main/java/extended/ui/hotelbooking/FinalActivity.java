package extended.ui.hotelbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class FinalActivity extends AppCompatActivity {

    RatingBar ratingBar;
    Button btnRate;

    String name, email, phone, address, numberofperson;
    String roomType, CheckinDate, CheckoutDate, edNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        TextView textView = findViewById(R.id.tv1);
        ratingBar=findViewById(R.id.rating_bar);
        btnRate=findViewById(R.id.btnRate);

        btnRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=String.valueOf(ratingBar.getRating());
                Toast.makeText(getApplicationContext(), "Star", Toast.LENGTH_SHORT).show();
            }
        });

        Intent i = getIntent();
        name = i.getStringExtra("name");
        email = i.getStringExtra("email");
        phone = i.getStringExtra("phone");
        address = i.getStringExtra("address");
        numberofperson = i.getStringExtra("numberofperson");
        roomType = i.getStringExtra("roomType");
        CheckinDate = i.getStringExtra("checkin");
        CheckoutDate = i.getStringExtra("checkout");
        edNum = i.getStringExtra("number");

        textView.setText(
                        "\nName: " + name +
                        "\n\nEmail: " + email +
                        "\n\nPhone: " + phone +
                        "\n\nAddress: " + address +
                        "\n\nNumber of Person: " + numberofperson +
                        "\n\nRoomType: " + roomType +
                        "\n\nCheckIn Date: " + CheckinDate +
                        "\n\nCheckOut Date: " + CheckoutDate +
                        "\n\nNumber of Rooms: " + edNum
        );
    }
}