package extended.ui.hotelbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class PersonalInfoActivity extends AppCompatActivity {
EditText edAddress,edName,edPhone,edEmail,edNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_info);
        Button btnSave=findViewById(R.id.button);
        edAddress=findViewById(R.id.edAddress);
        edName=findViewById(R.id.edName);
        edPhone=findViewById(R.id.edPhone);
        edEmail=findViewById(R.id.edEmail);
        edNumber=findViewById(R.id.edNumber);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent( PersonalInfoActivity.this,RoomInfoActivity.class);
                i.putExtra("name",edName.getText().toString());
                i.putExtra("address",edAddress.getText().toString());
                i.putExtra("phone",edPhone.getText().toString());
                i.putExtra("numberofperson",edNumber.getText().toString());
                i.putExtra("email",edEmail.getText().toString());

                startActivity(i);
            }
        });
    }
}