package extended.ui.hotelbooking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

Button btnBookNow;
Button btnBookNow2;
Button button2;
Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnBookNow=findViewById(R.id.btnBookNow);
        btnBookNow2=findViewById(R.id.btnBookNow2);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        btnBookNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent( MainActivity.this,PersonalInfoActivity.class);
                i.putExtra("Information","Single Bed Room");
                startActivity(i);
            }
        });

        btnBookNow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent( MainActivity.this,PersonalInfoActivity.class);
                i.putExtra("Information","Double Bed Room");
                startActivity(i);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent( MainActivity.this,LoginActivity.class);
                i.putExtra("Login","Login Information");
                startActivity(i);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent( MainActivity.this,PersonalInfoActivity.class);
                i.putExtra("Signup","Signup Information");
                startActivity(i);
            }
        });
    }
}